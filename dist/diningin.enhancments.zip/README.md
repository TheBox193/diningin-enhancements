# diningin-enhancements
Fix up Diningin with a few enhancements. 

# Install
Install on Chrome Webstore:
https://chrome.google.com/webstore/detail/diningin-enhancments/lkiekaajnilpmkppiglncmgnkjcfpmpj
